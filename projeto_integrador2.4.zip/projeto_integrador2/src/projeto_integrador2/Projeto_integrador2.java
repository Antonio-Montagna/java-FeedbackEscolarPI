package projeto_integrador2;

public class Projeto_integrador2 {

    public static void main(String[] args) {
        
        Tela_inicial ti = new Tela_inicial();
        ti.setVisible(true);

        //Aluno aluno1 = new Aluno("João Silva", "joao@email.com", "111.555.777-33", "12345", 34675);
       // Professor professor1 = new Professor("Alssandra pereira", "Alssandra@gmail.com", "123.321.213-11", "665765", "Matemática");
        
        //Feedbacks feedback1 = new Feedbacks("A aula de matemática foi excelente!", false, "Matemática", aluno1);
        
        //professor recebe feedback
       // professor1.adicionarFeedback(feedback1);
        
        //professor vizualiza feddback
        //professor1.VisualizarFeedbacks();
        
        //respoata do professor
       // professor1.responderFeedback(feedback1, "Obrigado pelo retorno! Vou continuar melhorando as aulas.");
        
    }
}
